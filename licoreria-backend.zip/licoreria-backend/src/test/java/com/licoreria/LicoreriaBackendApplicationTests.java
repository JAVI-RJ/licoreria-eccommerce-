package com.licoreria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LicoreriaBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
