package com.licoreria.controllers;

import com.licoreria.models.PedidoDetalle;
import com.licoreria.services.PedidoDetalleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/detalles")
@CrossOrigin(origins = "*")
public class PedidoDetalleController {

    @Autowired
    private PedidoDetalleService detalleService;

    @GetMapping
    public List<PedidoDetalle> getAll() {
        return detalleService.getAll();
    }

    @GetMapping("/{id}")
    public PedidoDetalle getById(@PathVariable Integer id) {
        return detalleService.getById(id);
    }

    @PostMapping
    public PedidoDetalle save(@RequestBody PedidoDetalle detalle) {
        return detalleService.save(detalle);
    }

    @PutMapping("/{id}")
    public PedidoDetalle update(@PathVariable Integer id, @RequestBody PedidoDetalle detalle) {
        return detalleService.update(id, detalle);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Integer id) {
        detalleService.delete(id);
    }
}
