package com.licoreria;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LicoreriaBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(LicoreriaBackendApplication.class, args);
	}

}
