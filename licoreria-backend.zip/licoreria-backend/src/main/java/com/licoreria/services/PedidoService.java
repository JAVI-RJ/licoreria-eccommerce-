package com.licoreria.services;

import com.licoreria.models.Pedido;
import com.licoreria.repositories.PedidoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PedidoService {

    @Autowired
    private PedidoRepository pedidoRepository;

    public List<Pedido> getAll() {
        return pedidoRepository.findAll();
    }

    public Pedido getById(Integer id) {
        return pedidoRepository.findById(id).orElse(null);
    }

    public Pedido save(Pedido pedido) {
        return pedidoRepository.save(pedido);
    }

    public Pedido update(Integer id, Pedido pedido) {
        if (pedidoRepository.existsById(id)) {
            pedido.setId_pedido(id);
            return pedidoRepository.save(pedido);
        }
        return null;
    }

    public void delete(Integer id) {
        pedidoRepository.deleteById(id);
    }
}

