package com.licoreria.services;

import com.licoreria.models.Cliente;
import com.licoreria.repositories.ClienteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ClienteService {

    @Autowired
    private ClienteRepository clienteRepository;

    public List<Cliente> getAll() {
        return clienteRepository.findAll();
    }

    public Cliente getById(Integer id) {
        return clienteRepository.findById(id).orElse(null);
    }

    public Cliente save(Cliente cliente) {
        return clienteRepository.save(cliente);
    }

    public Cliente update(Integer id, Cliente cliente) {
        if (clienteRepository.existsById(id)) {
            cliente.setId_cliente(id);
            return clienteRepository.save(cliente);
        }
        return null;
    }

    public void delete(Integer id) {
        clienteRepository.deleteById(id);
    }
}
