package com.licoreria.services;

import com.licoreria.models.Categoria;
import com.licoreria.repositories.CategoriaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CategoriaService {

    @Autowired
    private CategoriaRepository categoriaRepository;

    public List<Categoria> getAll() {
        return categoriaRepository.findAll();
    }

    public Categoria getById(Integer id) {
        return categoriaRepository.findById(id).orElse(null);
    }

    public Categoria save(Categoria categoria) {
        return categoriaRepository.save(categoria);
    }

    public Categoria update(Integer id, Categoria categoria) {
        if (categoriaRepository.existsById(id)) {
            categoria.setId_categoria(id);
            return categoriaRepository.save(categoria);
        }
        return null;
    }

    public void delete(Integer id) {
        categoriaRepository.deleteById(id);
    }
}

