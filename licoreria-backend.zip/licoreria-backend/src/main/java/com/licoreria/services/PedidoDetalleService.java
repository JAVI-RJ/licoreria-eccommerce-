package com.licoreria.services;

import com.licoreria.models.PedidoDetalle;
import com.licoreria.repositories.PedidoDetalleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PedidoDetalleService {

    @Autowired
    private PedidoDetalleRepository pedidoDetalleRepository;

    public List<PedidoDetalle> getAll() {
        return pedidoDetalleRepository.findAll();
    }

    public PedidoDetalle getById(Integer id) {
        return pedidoDetalleRepository.findById(id).orElse(null);
    }

    public PedidoDetalle save(PedidoDetalle detalle) {
        return pedidoDetalleRepository.save(detalle);
    }

    public PedidoDetalle update(Integer id, PedidoDetalle detalle) {
        if (pedidoDetalleRepository.existsById(id)) {
            detalle.setId_detalle(id);
            return pedidoDetalleRepository.save(detalle);
        }
        return null;
    }

    public void delete(Integer id) {
        pedidoDetalleRepository.deleteById(id);
    }
}
