package com.licoreria.services;

import com.licoreria.models.Producto;
import com.licoreria.repositories.ProductoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductoService {

    @Autowired
    private ProductoRepository productoRepository;

    public List<Producto> getAll() {
        return productoRepository.findAll();
    }

    public Producto getById(Integer id) {
        return productoRepository.findById(id).orElse(null);
    }

    public Producto save(Producto producto) {
        return productoRepository.save(producto);
    }

    public Producto update(Integer id, Producto producto) {
        if (productoRepository.existsById(id)) {
            producto.setId_producto(id);
            return productoRepository.save(producto);
        }
        return null;
    }

    public void delete(Integer id) {
        productoRepository.deleteById(id);
    }
}
