import { Component, OnInit } from '@angular/core';
import { Cliente } from 'src/app/models/cliente.model';
import { ClienteService } from 'src/app/services/cliente.service';

@Component({
  selector: 'app-clientes',
  templateUrl: './clientes.component.html',
  styleUrls: ['./clientes.component.css']
})
export class ClientesComponent implements OnInit {
  clientes: Cliente[] = [];
  nuevoCliente: Cliente = { nombre: '', email: '', contraseña: '' };
  modoEditar = false;

  constructor(private clienteService: ClienteService) {}

  ngOnInit(): void {
    this.obtenerClientes();
  }

  obtenerClientes(): void {
    this.clienteService.getAll().subscribe((data: Cliente[]) => {
      this.clientes = data;
    });
  }

  registrarCliente(): void {
    this.clienteService.create(this.nuevoCliente).subscribe(() => {
      this.obtenerClientes();
      this.nuevoCliente = { nombre: '', email: '', contraseña: '' };
    });
  }

  editarCliente(cliente: Cliente): void {
    this.nuevoCliente = { ...cliente };
    this.modoEditar = true;
  }

  actualizarCliente(): void {
    if (!this.nuevoCliente.id_cliente) return;
    this.clienteService.update(this.nuevoCliente.id_cliente, this.nuevoCliente).subscribe(() => {
      this.obtenerClientes();
      this.nuevoCliente = { nombre: '', email: '', contraseña: '' };
      this.modoEditar = false;
    });
  }

  eliminarCliente(id: number): void {
    this.clienteService.delete(id).subscribe(() => this.obtenerClientes());
  }
}
