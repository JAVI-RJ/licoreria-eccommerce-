export interface Cliente {
  id_cliente?: number;
  nombre: string;
  email: string;
  contraseña: string;
}
